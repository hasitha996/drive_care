package com.example.assigment_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
